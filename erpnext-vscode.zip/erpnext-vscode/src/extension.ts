import * as vscode from 'vscode';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export function activate(context: vscode.ExtensionContext) {
    console.log('ERPNext AST Analyzer extension is now active!');

    // Index command
    let indexDisposable = vscode.commands.registerCommand('erpnext-analyzer.index', async () => {
        // Get path to index (default to erpnext folder relative to extension)
        const extensionPath = context.extensionPath;
        const erpnextPath = path.join(extensionPath, '..', 'erpnext');
        const cliPath = path.join(extensionPath, '..', 'cli.py');
        const pythonPath = path.join(extensionPath, '..', '.venv', 'Scripts', 'python.exe');

        try {
            const { stdout, stderr } = await execAsync(`"${pythonPath}" "${cliPath}" index "${erpnextPath}"`, { cwd: path.dirname(cliPath) });
            vscode.window.showInformationMessage('Indexing complete');
            if (stdout) console.log(stdout);
            if (stderr) console.warn(stderr);
        } catch (error: any) {
            vscode.window.showErrorMessage(`Indexing failed: ${error.message}`);
        }
    });

    // Ask command
    let askDisposable = vscode.commands.registerCommand('erpnext-analyzer.ask', async () => {
        const query = await vscode.window.showInputBox({
            prompt: 'Enter your query for the ERPNext analyzer'
        });
        if (!query) return;

        const extensionPath = context.extensionPath;
        const cliPath = path.join(extensionPath, '..', 'cli.py');
        const pythonPath = path.join(extensionPath, '..', '.venv', 'Scripts', 'python.exe');

        try {
            const { stdout, stderr } = await execAsync(`"${pythonPath}" "${cliPath}" ask "${query}"`, { cwd: path.dirname(cliPath) });
            if (stderr) {
                vscode.window.showWarningMessage(`Warnings: ${stderr}`);
            }
            // Show output in a new document
            const outputDoc = await vscode.workspace.openTextDocument({ content: stdout, language: 'plaintext' });
            await vscode.window.showTextDocument(outputDoc);
        } catch (error: any) {
            vscode.window.showErrorMessage(`Query failed: ${error.message}`);
        }
    });

    context.subscriptions.push(indexDisposable, askDisposable);
}

export function deactivate() {}